class Piece

  def initialize

  end
end

class NullPiece < Piece


end
